=== Zero ecoimpact - WooCommerce ===
Contributors: n4zim
Tags: woocomerce, zei, ecology, api
Requires at least: 3.7
Tested up to: 4.7
Stable tag: 1.1
License: GPLv3

WooCommerce extension for Zero ecoimpact API

== Description ==
Use your Zero ecoimpact company account with your offers and rewards, from the ZEI API, for WooCommerce plugin


== Installation ==

Upload plugin to your WP, activate it and enter your [ZEI API key](https://zero-ecoimpact.org/) (Company Profile > My tools > API).

== Changelog ==

= 1.0 =
* API auth
* Offers validation

